using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json.Linq;
using System.Net.Http;

public class WeatherModel : PageModel
{
    private readonly IHttpClientFactory _httpClientFactory;

    public WeatherModel(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory;
    }

    [BindProperty]
    public string City { get; set; }

    public WeatherInfo WeatherInfo { get; set; }

    public async Task<IActionResult> OnPostAsync()
    {
        if (string.IsNullOrWhiteSpace(City))
        {
            ModelState.AddModelError("", "City name cannot be empty.");
            return Page();
        }

        string apiKey = "a0e3039d410843f8b77135108250204";
        string apiUrl = $"https://api.weatherapi.com/v1/current.json?key={apiKey}&q={City}&aqi=no";

        var client = _httpClientFactory.CreateClient();

        try
        {
            var response = await client.GetAsync(apiUrl);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();
            var weatherData = JObject.Parse(json);

            WeatherInfo = new WeatherInfo
            {
                Temperature = weatherData["current"]?["temp_c"]?.ToObject<double>() ?? 0,
                Condition = weatherData["current"]?["condition"]?["text"]?.ToString() ?? "Unknown",
                Humidity = weatherData["current"]?["humidity"]?.ToObject<int>() ?? 0,
                WindSpeed = weatherData["current"]?["wind_kph"]?.ToObject<double>() ?? 0
            };
        }
        catch (Exception ex)
        {
            ModelState.AddModelError("", $"Error retrieving weather: {ex.Message}");
        }

        return Page();
    }
}

public class WeatherInfo
{
    public double Temperature { get; set; }
    public string Condition { get; set; }
    public int Humidity { get; set; }
    public double WindSpeed { get; set; }
}
