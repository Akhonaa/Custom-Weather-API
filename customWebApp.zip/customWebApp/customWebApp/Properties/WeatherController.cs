﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

[Route("api/weather")]
[ApiController]
public class WeatherController : ControllerBase
{
    private readonly HttpClient _httpClient;
    private readonly string apiKey = "a0e3039d410843f8b77135108250204"; // Replace with your API key

    public WeatherController(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    [HttpGet("{city}")]
    public async Task<IActionResult> GetWeather(string city)
    {
        if (string.IsNullOrWhiteSpace(city))
        {
            return BadRequest(new { message = "City name cannot be empty." });
        }

        string apiUrl = $"https://api.weatherapi.com/v1/current.json?key={apiKey}&q={city}&aqi=no";

        try
        {
            HttpResponseMessage response = await _httpClient.GetAsync(apiUrl);

            if (!response.IsSuccessStatusCode)
            {
                return NotFound(new { message = $"Weather data for '{city}' not found." });
            }

            string json = await response.Content.ReadAsStringAsync();
            JObject weatherData = JObject.Parse(json);

            var result = new
            {
                City = city,
                Temperature = weatherData["current"]["temp_c"] + "°C",
                Condition = weatherData["current"]["condition"]["text"],
                Humidity = weatherData["current"]["humidity"] + "%",
                WindSpeed = weatherData["current"]["wind_kph"] + " km/h"
            };

            return Ok(result);
        }
        catch (HttpRequestException)
        {
            return StatusCode(500, new { message = "Network error: Unable to retrieve weather data." });
        }
        catch (System.Exception ex)
        {
            return StatusCode(500, new { message = $"Unexpected error: {ex.Message}" });
        }
    }
}
